# 水下声呐图像分类 HW-NAS 项目：五维度对比文献调研报告

## TL;DR
- 已为项目定位 5 个维度的可对比、可引用文献：维度一（声呐分类，含 NKSID 直接基线 PLUD/DMCL）、维度二（FPGA vs V100/Xeon 效率）、维度三（NAS 策略有效性）、维度四（算子消融）、维度五（硬约束+Pareto 闭环）。
- 最重要的直接基线：Jiao et al.（ESWA 2024，CCF-C）提出的 NKSID 数据集与 PLUD 方法（Macro-F1 = 83.68%），以及 DMCL（Scientific Reports 2025）报告的 "improvements of 5.79% in Macro-F1 (89.47% vs. 83.68%)"——这是本项目 macro_f1/top1 必须对齐的准确率标杆。
- 方法论上，FPGA/DNN co-design（DAC 2019）、EDD（DAC 2020）、FNAS（DAC 2019）提供了"LUT/DSP/BRAM 硬约束 + 解析模型/HLS 估计 + Pareto 选择 + 板级反馈"的闭环范式，直接对应项目的"约束搜索—重训练—硬件验证—反馈修正"流程。

## Key Findings

**总体判断**：本项目所处的交叉领域（声呐图像分类 × HW-NAS × 资源受限 FPGA 部署）目前几乎没有完全重合的已发表工作——这既是本项目的核心创新空间，也意味着 Related Work 需要从三条独立支线拼合基线：(1) 声呐分类的 SOTA 精度线（多在 ESWA / Neurocomputing / Applied Acoustics / Remote Sensing 等，CCF-B/C 为主，严格 CCF-A/B 的声呐分类论文稀缺）；(2) FPGA-NAS 协同设计的方法学线（DAC / ICCAD / ICLR / CVPR / TCAD / FCCM 等 CCF-A/B）；(3) FPGA-vs-GPU/CPU 效率对比线（FCCM / 期刊）。下面分维度给出代表性论文与关键数据。

## Details

### 维度一：声呐图像分类准确率对比（含 NKSID 直接基线）

本维度最关键，因为项目使用 NKSID 数据集，必须与该数据集上已发表方法对齐 macro_f1/top1/weighted_f1。

1. **Jiao, W.; Zhang, J.; Zhang, C. "Open-set recognition with long-tail sonar images." Expert Systems with Applications (ESWA), 2024, vol. 249, Part A, 123495.**（CCF-C，中科院一区 Top 期刊）
   - **这是 NKSID 数据集的原始出处**。NKSID：2617 张前视声呐（ROV 搭载 Oculus M750d 多波束声呐，750 kHz/1.2 MHz，2–15 m 距离）图像，8 类，天然长尾分布。
   - 提出 PLUD（Push the right Logit Up and the wrong logit Down）方法，首次为声呐开集长尾识别（Sonar-OLTR）建立 benchmark，并提出改进的 OSR 评价指标（OSCRmac、OSFM）以适配长尾。PLUD 在 NKSID 上 Macro-F1 = 83.68%、Normalized Accuracy = 78.52%、OSCRmac = 87.48%、OSFM = 87.34%（数值见 DMCL 原文对比表）。
   - 声呐专用协议：设计五折交叉验证 + 5 组随机 known/unknown 类划分的实验协议。实验硬件为 Intel Xeon E3-1275 v6 CPU + NVIDIA RTX 2080Ti。

2. **"Dynamic margin contrastive learning for open-set recognition in long-tailed sonar imagery." Scientific Reports, 2025 Jul 2; 15(1):22617. doi:10.1038/s41598-025-04877-6（PubMed 40595936, PMC12214808）。**
   - **NKSID 上目前最强的公开基线**，骨干网络为 ResNeXtVT。原文逐字表述："DMCL's superior performance compared to existing methods like PLUD, achieving improvements of 5.79% in Macro-F1 (89.47% vs. 83.68%), 3.38% in Normalized Accuracy (81.90% vs. 78.52%), 3.53% in OSCRmac (91.01% vs. 87.48%), and 5.87% in OSFM (93.21% vs. 87.34%)"，并注明 "DMCL achieves 89.47% compared to PLUD's 83.68%, showing a significant improvement of 5.79% points (± 1.2% standard deviation across folds)"。
   - NKSID 长尾结构（逐字引自本文）："head classes like 'Floats' (951 samples) and 'Tire' (834 samples) having significantly more examples than tail classes like 'Small Propeller' (94 samples) and 'Fishing Net' (20 samples)"。
   - 声呐专用方法：类频率驱动的动态 margin 机制（应对长尾）+ 对比学习特征表示 + 不确定性估计模块（应对开集未知类）。**本项目 macro_f1 目标应对标 83.68%–89.47% 区间**。

3. **"FATL: Frozen-feature augmentation transfer learning for few-shot long-tailed sonar image classification." Neurocomputing, 2025, S0925231225013244.**（CCF-C）
   - 在 KLSG、FLSMDD、NKSID 三个声呐数据集上验证。声呐专用方法：冻结特征增强（数值 + 通道维对比学习丰富特征空间）应对小样本；平衡采样策略（训练集拆分为多个平衡子集，减少采样偏置）应对长尾。直接针对声呐"样本少、长尾"痛点。

4. **Huo, G.; Wu, Z.; Li, J. "Underwater Object Classification in Sidescan Sonar Images Using Deep Transfer Learning and Semisynthetic Training Data." IEEE Access, 2020（SeabedObjects-KLSG 数据集）。**
   - 构建 KLSG 真实侧扫声呐数据集（385 wreck、36 drowning victim、62 airplane、129 mine、578 seafloor）。声呐专用方法：半合成数据生成（光学图像输入 + 图像分割 + 不同区域强度分布模拟）应对类别不均衡；迁移预训练 CNN 分类准确率超过 90%。

5. **Kamal Basha S 等（SRM/IIT Madras）"A Novel Context-adaptive Fusion of Shadow and Highlight Regions for Efficient Sonar Image Classification." arXiv 2506.01445, 2025。**
   - 声呐专用特征工程的典型代表：显式利用**声影区（acoustic shadow）与高亮区（highlight）**的互补几何/结构信息，双流注意力融合（shadow-aware + raw image）+ 上下文自适应分类器选择 + 区域感知去噪模型（可解释性驱动优化）。提出 S3Simulator+（物理噪声仿真数据集）。**这是"声呐独特判别性特征"最直接的示例**，其"shadow/highlight 显式建模 + 去噪算子"思路可类比本项目的 denoise/edge 专用算子。

6. **Huo et al. "Underwater sonar image classification using adaptive weights convolutional neural network (AW-CNN)." Applied Acoustics.**
   - 声呐专用方法：针对声呐图像"低对比度、边缘模糊、高噪声"设计自适应权重 CNN（ResNet-ACW，非对称卷积），显式利用目标高亮区、阴影区、海底混响区三类区域的物理成因差异。

7. **"Side-Scan Sonar Image Classification Based on Joint Image Deblurring-Denoising and Pre-Trained Feature Fusion Attention Network." Electronics, 2025, 14(7):1287（MDPI）。**
   - 声呐专用方法：联合去模糊-去噪（变换域滤波 + 上下采样）在降噪同时保留/增强边缘与纹理特征——与本项目 denoise + edge 算子高度契合。消融显示去噪模块带来约 1.47%–1.48% 准确率提升。显式建模混响与散斑噪声（speckle noise，服从 Rayleigh 分布的乘性噪声）。

**声呐专用判别性特征小结**（供 Related Work 组织）：目标/回波强度（backscattering intensity）、声影区（acoustic shadow）几何、高亮-阴影模式关系（HS-LRT）、海底底质纹理、单通道灰度预处理、散斑噪声（multiplicative Rayleigh）建模，以及针对小样本/长尾的迁移学习 / 半合成数据 / 平衡采样 / 对比学习。

### 维度二：硬件效率对比（FPGA vs V100/Xeon 级基线）

为项目"如何设计 FPGA vs V100/Xeon 效率对比实验"提供方法论与数据基准。核心指标：latency、throughput(FPS)、power(W)、能效(GOPS/W 或 FPS/W)、单位推理能耗。

1. **Jiang, C.; Ojika, D.; Patel, B.; Lam, H. "Optimized FPGA-based Deep Learning Accelerator for Sparse CNN using High Bandwidth Memory." IEEE FCCM。**（CCF-B，FPGA 领域顶会）
   - FPGA：Intel Stratix 10 MX + HBM2；基线：server-class Intel SkyLake CPU、**NVIDIA V100 GPU**。
   - 摘要逐字："2.7x/3x performance improvement compared to an FPGA with DDR4, 2.2x/2.1x speedup against a server-class Intel SkyLake CPU, and comparable performance with 1.7x/2x power efficiency"（对 ResNet-50 / MobileNet）。即相比 V100 **性能相当但能效高 1.7×/2×**；相比 SkyLake CPU 加速 2.2×/2.1×；相比 32 核 CPU 能效 3.5×/3.3×。**这是最贴合项目"FPGA vs V100"叙事的顶会证据**。

2. **Li, C.; Xu, R.; Lv, Y.; Zhao, Y.; Jing, W. "Edge Real-Time Object Detection and DPU-Based Hardware Implementation for Optical Remote Sensing Images." Remote Sensing, 2023, 15(16):3975。**（中科院一区）
   - FPGA：Xilinx ZCU104（DPU + Vitis AI, INT8）；基线：Intel i7-6700 CPU、**NVIDIA Tesla V100**。
   - 原文逐字："an average of 27.97 FPS and an average power consumption of 15.82 W on the FPGA... compared to the GPU, the power consumption was reduced by 89.72% and the throughput was increased by 34.47%"，相比 i7-6700 CPU 功耗降 62.11%、吞吐升 189.84%。

3. **"Design optimization for high-performance computing using FPGA." arXiv 2304.12474, 2023（Tensil AI；预印本，正式发表状态需核实）。**
   - FPGA：Xilinx ZCU104@100MHz；基线：**Intel Xeon E5-2697 CPU**、NVIDIA GTX 1080 Ti GPU。
   - 清晰的三方能效表：Xeon E5-2697 = 0.19 GOP/s/W（145 W）；GTX 1080 Ti = 0.94 GOP/s/W（250 W）；ZCU104 = 4.05 GOP/s/W（5.21 W）。**FPGA 能效约为 GPU 的 4.3×、CPU 的 21.3×**，主要来自极低功耗。

4. **"QuantLaneNet: A 640-FPS and 34-GOPS/W FPGA-Based CNN Accelerator for Lane Detection." PMC10422460, 约 2023（venue 待确认，可能 Sensors / IEEE Access）。**
   - FPGA：Xilinx Virtex-7 VC707（INT8）；基线：**NVIDIA Tesla T4**。
   - 结果：FPGA 640 FPS @ 10.309 W = 345.6 GOPS = 33.52 GOPS/W；T4 上同模型 348.34 FPS（FPGA 约 1.84× FPS）。

5. **"FPGA-Based Neural Network Accelerators for Space Applications: A Survey." arXiv 2504.16173** 汇总数据：某 CNN 加速器 @200MHz 消耗 14.97 W、能效 12.18–25.83 GOP/s/W，优于 Intel Xeon E5-2697v4 CPU（0.37–1.47 GOP/s/W）与 NVIDIA TITAN Xp GPU（2.45–23.16 GOP/s/W）；另有 ZCU102 vs Tesla K80：85.677 FPS vs 19.861 FPS、30 W vs 135 W、推理 0.7 s vs 3.128 s。

6. **"Algorithm and Hardware Co-design for Reconfigurable CNN Accelerator." arXiv 2111.12787** 提供 CPU/GPU/FPGA 三方在 ImageNet 上的 Latency(ms) 与 Enrg. Eff.(FPS/W) 对比表模板——**可直接作为本项目对比表的排版参考**。

**方法论要点**：主流做法是固定同一模型/任务，在 FPGA、桌面/服务器 GPU、服务器 CPU 上分别测 latency / throughput / power，用 nvidia-smi 测 GPU 功耗、Xilinx Power Estimator 测 FPGA 功耗，报告 GOPS/W 或 FPS/W 与相对倍数。FPGA 的优势几乎总是体现在"能效比"而非绝对吞吐（低功耗驱动）——本项目应据此设定预期：AV7K325 相比 V100 能效应高约 1.7×–4×、相比 Xeon 高约 10×–21×。

### 维度三：NAS 搜索策略有效性对比

对应项目的 Random search / RL / Proxyless（可微分）三类策略对比。

1. **Cai, H.; Zhu, L.; Han, S. "ProxylessNAS: Direct Neural Architecture Search on Target Task and Hardware." ICLR 2019（arXiv 1812.00332）。**（CCF-A）
   - **同时给出 Proxyless-G（梯度）与 Proxyless-R（REINFORCE/RL）两个变体**，正是项目"RL vs 梯度"对比的经典范式。将延迟建模为可微连续函数作为正则项。结果：ImageNet 74.6% top-1、78 ms 移动延迟（比 MobileNetV2 快 1.83×）；相比 MnasNet top-1 高 0.6%，且原文逐字："we are much more resource efficient: the GPU-hour is 200× fewer than MnasNet"（约 200 GPU-hours；MnasNet 侧成本据 arXiv 2510.08993 为 "MnasNet... requiring over 40,000 GPU-hours"）。有效性维度：搜索成本(GPU-hours) + 精度-延迟权衡。

2. **Tan, M. et al. "MnasNet: Platform-Aware Neural Architecture Search for Mobile." CVPR 2019。**（CCF-A）
   - RL-based NAS 代表，reward = 精度 × [延迟/目标]^w。搜索成本极高（估算 ~91×10³ GPU-hours）。是"RL 策略搜索成本高"的标准引用。

3. **Wu, B. et al. "FBNet: Hardware-Aware Efficient ConvNet Design via Differentiable NAS." CVPR 2019。**（CCF-A）
   - 可微分 NAS，搜索成本仅 216 GPU-hours，比 MnasNet 快 421×、比 NAS 快 222×、比 DARTS 快 1.33×。有效性对比维度：搜索成本(GPU-hours) + 精度-延迟-FLOPs 三方权衡（FBNet-B 比 MnasNet top-1 高 0.1%、延迟低 0.6 ms）。

4. **Li, L.; Talwalkar, A. "Random Search and Reproducibility for Neural Architecture Search." UAI 2019。**（CCF-B）
   - **关键的"Random Search 基线竞争力"论文**：随机搜索 + early-stopping 在 PTB/CIFAR-10 上不逊于 ENAS；random search + weight-sharing 达到 SOTA。**为项目将 Random search 作为合法对照组提供有力依据**，并强调 NAS 可复现性问题。

5. **Liu, H.; Simonyan, K.; Yang, Y. "DARTS: Differentiable Architecture Search." ICLR 2019。**（CCF-A）
   - 可微分 NAS 奠基工作，是梯度类策略的基准对照。

**有效性评估维度小结**：(a) 搜索成本 GPU-hours/GPU-days；(b) Pareto 前沿质量（支配关系、hypervolume）；(c) 最终模型精度-效率（延迟/能耗）权衡；(d) 可复现性/稳定性。MODNAS（ICLR 2025）用 hypervolume(HV) 衡量多目标 Pareto 前沿质量并与 HW-NAS-Bench（FPGA、Eyeriss 能耗表）联用，可作为 HV 指标与硬件代价查表的引用。

### 维度四：算子消融研究方法

**(a) 新增/专用算子贡献度消融**（类比 denoise/edge 算子）：
- **FPGA/DNN co-design（Hao et al., DAC 2019）**：以 "Bundle"（算子组合模板）为单位做粗粒度评估——对每个 Bundle 捕获 latency-resource-accuracy 三维特征，据此筛选有潜力的 Bundle 进入细粒度 DNN 探索。**这正是"专用算子先做可行性/贡献度评估、再决定是否加入搜索空间"的范式**，直接对应项目 denoise/edge 算子需先过 LUT/DSP/route 验证的设计。
- **Context-adaptive Shadow/Highlight（arXiv 2506.01445）** 与 **Joint Deblurring-Denoising（Electronics 2025, 14(7):1287）**：通过"有无去噪/shadow 模块"的对比消融，量化专用模块对精度的贡献（后者约 +1.47%–1.48%）——可类比 denoise 算子消融。
- **NetAdaptV2（arXiv 2104.00031）**：Channel-Level Bypass Connections (CBC) 消融——加入 CBC 使发现的网络在同等延迟下精度 +6.5%，训练开销仅 1.2×。示范"新增连接/算子对精度与硬件成本的双重影响"分析。

**(b) 标准算子组合消融**（MBConv / fused_mbconv / skip connection 等）：
- **Single-Path NAS（Stamoulis et al., ECML-PKDD 2019）**：kernel-based 精度-效率权衡消融——以 MobileNetV2 为骨干，对比 MBConv-3×3-6 与 MBConv-5×5-6，验证 3×3 作为 5×5 子核可捕获精度-效率权衡（Table II 给出 top-1/top-5）。**标准算子类型/核尺寸消融的模板**。
- **One-Shot Ensemble NAS（arXiv 2104.00597）**：对比不同 shrink 度量对 Kendall Tau 与 top-1 的影响——算子数量/搜索空间维度消融范式。
- **EfficientNetV2（Tan & Le, ICML 2021）**：Fused-MBConv vs MBConv 的算子替换消融（早期 stage 用 Fused-MBConv 加速），与项目 fused_mbconv/MBConv 选择直接对应。
- **Differentiable Model Scaling（arXiv 2405.07194）**：宽度/深度搜索空间消融（粗粒度 vs 细粒度）。

### 维度五：硬约束 + Pareto 前沿候选选择策略（闭环）

对应项目"LUT/DSP/BRAM/延迟预算作硬约束提前淘汰 + 解析/LUT 估计快筛 + 真实路由/板测结果反馈校正"。

1. **Jiang, W.; Zhang, X.; Sha, E. et al. "Accuracy vs. Efficiency: Achieving Both through FPGA-Implementation Aware NAS (FNAS)." DAC 2019。**（CCF-A）
   - 定义包含 FPGA 规格（tiling 配置）的硬件搜索空间；用**性能抽象模型（analytical model）在不训练的情况下估计延迟**，从而**快速剪除不满足硬件规格的架构**——精确对应项目"解析模型/LUT 查表快速估计延迟并硬约束淘汰"。RL 范式。

2. **Hao, C. et al. "FPGA/DNN Co-Design（Auto-DNN + Auto-HLS）." DAC 2019。**（CCF-A）
   - PYNQ-Z1（4.9 Mbit BRAM、220 DSP、53,200 LUT、106,400 FF）为目标；**Auto-HLS 直接生成可综合 C 代码做 latency/resource 估计**，board-level 实测反馈。三档 DNN 的 IoU-FPS Pareto 选择（DNN1 达 68.6% IoU @ 17.4 FPS@150MHz 等）。相比 SOTA FPGA：IoU +6.2%、FPS 2.48×、功耗 -40%、能效 2.5×。**"HLS 估计 + 板级实测反馈"闭环的最佳范式**，与项目 COM5 固定输入延迟板测反馈高度对应。

3. **Li, Y.; Hao, C. et al. "EDD: Efficient Differentiable DNN Architecture and Implementation Co-search." DAC 2020（arXiv 2005.02563）。**（CCF-A）
   - 将 DNN 搜索变量与硬件实现变量融合到同一可微空间，梯度下降协同搜索，12 GPU-hour 完成。FPGA 目标吞吐比 DNNBuilder 高 1.45×，GPU 目标比 ProxylessNAS 快 1.40×。可微分硬件感知协同搜索代表。

4. **Lu, Q.; Jiang, W.; Xu, X.; Shi, Y.; Hu, J. "On Neural Architecture Search for Resource-Constrained Hardware Platforms." ICCAD 2019。**（CCF-B）
   - 直接针对资源受限硬件（FPGA）的 NAS，将资源/延迟作为硬约束。**与项目"资源受限 FPGA（AV7K325，低 LUT/DSP）"设定最贴近**。

5. **Jiang, W. et al. "Hardware/Software Co-Exploration of Neural Architectures." IEEE TCAD 2020（DAC 2019 扩展，arXiv 1907.04650）。**（CCF-A 期刊）
   - Xilinx XC7Z015 FPGA 上对比三种策略：纯 HW-aware NAS（84.53%、16.2 FPS、0.84 GOPS/W）、顺序优化（84.53%、29.7 FPS、1.36 GOPS/W）、协同探索（85.19%、35.5 FPS、1.91 GOPS/W）。**清晰展示"协同 vs 顺序"的 Pareto 改进（吞吐 +16.33%、能效 +28.80%）**。

6. **surrogate/LUT 快筛范式**：SNAC-Pack（rule4ml + wa-hls4ml GNN 代理）在搜索循环内用回归代理预测 BRAM/DSP/FF/LUT/II/latency，将全量 hls4ml 综合保留给最终验证——**正是项目"搜索期估计 + 最终硬件验证"两阶段的直接参照**。文献综述指出 LUT-based 求和法"作为快速筛选步骤淘汰明显不可行的设计"（Wang et al. 2020b）。

7. **CoDANet: Hardware-Aware NAS for Optimized Deep Learning on FPGAs（IEEE 会议）**：将硬件反馈集成进 NAS，在性能优先设置下 LUT 使用降 85.3% 而 AUC 仅降 1.6%——硬件反馈闭环 + 资源-精度权衡的近期示例。

### 综合对比基准表格建议（本项目 vs. 代表性工作）

| 维度 | 本项目（NKSID + AV7K325 HW-NAS） | 代表性对标工作 | 关键对比量 |
|---|---|---|---|
| 声呐分类准确率 | retrain150 后的 macro_f1 / top1 / weighted_f1 | PLUD（ESWA'24, Macro-F1 83.68%）、DMCL（Sci.Rep.'25, Macro-F1 89.47%）、FATL、AW-CNN | Macro-F1 / Normalized Acc / OSCRmac；目标区间 83.68%–89.47% |
| 硬件效率（FPGA vs V100/Xeon） | AV7K325 latency / FPS / power(W) / FPS/W / energy-per-inf，对比 V100 + Xeon | Jiang FCCM（vs V100 能效 1.7×/2×）、RS'23（vs V100 功耗 -89.72%/吞吐 +34.47%）、ZCU104（4.05 GOP/s/W）、Co-design TCAD 表模板 | GOPS/W、FPS/W、功耗降幅%、吞吐提升% |
| NAS 策略有效性 | Random / RL / Proxyless(gradient) 三策略对比 | ProxylessNAS-G/R（ICLR'19）、MnasNet、FBNet、Li&Talwalkar（UAI'19 随机搜索基线） | 搜索成本 GPU-hours、Pareto HV、精度-延迟权衡 |
| 算子消融方法 | denoise/edge 专用算子（有无 + stage 位置 + 精度/硬件双重）；MBConv/fused/skip 标准算子（类型/深度/宽度） | Bundle 粗粒度评估（DAC'19）、Context-adaptive shadow 模块消融、Single-Path NAS、EfficientNetV2、NetAdaptV2 | ΔMacro-F1、ΔLUT/DSP/BRAM、Δlatency |
| Pareto/硬约束选择 | LUT/DSP/BRAM/延迟硬约束提前淘汰 + 解析/LUT 快筛 + 板级反馈校正 | FNAS（DAC'19 解析剪枝）、FPGA/DNN co-design（Auto-HLS + 板测）、EDD、Lu ICCAD'19、Co-Exploration TCAD、SNAC-Pack（代理快筛 + hls4ml 终验） | 是否闭环、约束命中率、HV、板测 vs 估计误差 |

## Recommendations

**分阶段建议**：

1. **第一优先级（准确率基线对齐）**：Related Work 与实验对比必引 **Jiao et al. ESWA 2024（PLUD/NKSID）** 与 **DMCL Scientific Reports 2025**——这是 NKSID 上唯一直接可比的 macro_f1/top1 数字（83.68% / 89.47%）。判据：若项目搜索出的紧凑 CNN 在 retrain150 后 Macro-F1 ≥ 80%，可主张"在极低硬件成本下逼近 SOTA 精度"；若 ≥ 85% 则精度-效率双赢叙事成立；若 < 80%，需以硬件效率优势（能效、可部署性）作为主卖点补偿。

2. **第二优先级（方法学定位）**：以 **FNAS（DAC'19）、FPGA/DNN co-design（DAC'19）、EDD（DAC'20）、Hardware/Software Co-Exploration（TCAD'20）** 作为方法学对标——它们确立了"硬约束提前淘汰 + HLS/解析估计 + 板级反馈"范式。项目的增量创新点应明确定位为：(a) 首次将该范式用于**声呐单通道、强噪声、长尾分类**；(b) 引入 **denoise/edge 声呐专用算子并做 LUT/DSP/route 可行性门控**（现有 FPGA-NAS 工作均无领域专用算子这一层）。

3. **第三优先级（效率对比实验设计）**：仿照 **Jiang FCCM（vs V100 能效 1.7×/2×）** 与 **Co-design TCAD 表格**，设计"本项目 FPGA(AV7K325) vs V100 GPU vs Xeon CPU"三方表，报告 latency、FPS、power(W)、FPS/W、energy-per-inference。基准预期：FPGA 能效比 V100 高约 1.7×–4×、比 Xeon 高约 10×–21×。功耗测量用 Xilinx Power Estimator（FPGA）、nvidia-smi（GPU）。

4. **策略对比实验**：以 **Li & Talwalkar UAI'19** 为据，将 Random Search 作为合法对照；对比 Random / RL(Proxyless-R) / Proxyless-G(gradient) 三者的搜索成本(GPU-hours)、Pareto hypervolume、最终候选精度-延迟权衡，并报告可复现性（多次运行方差）。

5. **消融实验设计**：专用算子（denoise/edge）用"有无 + 不同 stage 位置 + 精度/硬件成本双重"消融（参照 Bundle 粗粒度评估 + Context-adaptive shadow 模块消融）；标准算子（MBConv/fused_mbconv/skip）用类型/深度/通道宽度消融（参照 Single-Path NAS、EfficientNetV2、NetAdaptV2）。每项消融均同时报告 ΔMacro-F1 与 ΔLUT/DSP/BRAM/Δlatency。

## Caveats
- **CCF 等级现实**：声呐分类高精度工作多发表于 ESWA(CCF-C)、Neurocomputing(CCF-C)、Applied Acoustics、Remote Sensing、Electronics 等；严格的 CCF-A/B 声呐图像分类论文极稀缺，而 CCF-A/B 集中在 NAS/FPGA 方法学侧（DAC、ICCAD、ICLR、CVPR、TCAD、FCCM）。因此"声呐 × CCF-A/B"几乎不可得，需接受该领域现实——本报告据此以"声呐精度线（B/C 期刊）+ 方法学线（A/B 会议/期刊）"拼合。
- **待核实项**：DMCL 的部分数值与若干 FPGA-vs-V100 数据来自期刊/综述转引；QuantLaneNet 的正式 venue、arXiv 2304.12474 的正式发表状态、以及各文的 CCF 等级，均应在正式引用前对照最新 CCF 推荐目录与原文逐一核验。
- 部分效率对比（如 LHCb Alveo 数据）混合了实测与 Vivado 理论估计值，不建议作为实测能效的主引用。
- 项目所处交叉点缺乏完全重合先例，既是创新点也意味着对比需跨子领域拼合；对比表中"本项目"列的若干维度（尤其声呐专用算子的 FPGA 可行性门控）可能无直接对照工作，属新贡献，应在论文中明确标注为 novelty 而非简单沿用基线。