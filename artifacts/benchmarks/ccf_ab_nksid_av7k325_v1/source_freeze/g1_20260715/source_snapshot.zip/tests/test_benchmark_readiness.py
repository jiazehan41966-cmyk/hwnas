import pytest

from hwnas_fpga.benchmarks.readiness import build_readiness_report, make_requirement


def test_readiness_is_fail_closed_until_every_requirement_passes() -> None:
    report = build_readiness_report(
        "campaign",
        [
            make_requirement("sources", "sources", passed=True, observed=5, required=5),
            make_requirement("formal", "formal", passed=False, observed=0, required=15),
        ],
    )
    assert report["status"] == "NOT_READY"
    assert report["formal_execution_ready"] is False
    assert report["blocking_requirement_ids"] == ["formal"]


def test_readiness_requires_nonempty_complete_requirement_set() -> None:
    empty = build_readiness_report("campaign", [])
    assert empty["status"] == "NOT_READY"
    complete = build_readiness_report(
        "campaign",
        [make_requirement("one", "one", passed=True, observed=True, required=True)],
    )
    assert complete["status"] == "READY"


def test_duplicate_requirement_ids_are_rejected() -> None:
    row = make_requirement("same", "same", passed=True, observed=True, required=True)
    with pytest.raises(ValueError, match="must be unique"):
        build_readiness_report("campaign", [row, row])
