from pathlib import Path

import torch
from torch.utils.data import DataLoader, TensorDataset

from hwnas_fpga.benchmarks.sure import (
    SureAuthorRecipeConfig,
    apply_author_cosine_classifier,
    indexed_training_loader,
    load_sure_author_components,
)
from hwnas_fpga.models.backbones import SimpleCNN


REPO_ROOT = Path(__file__).resolve().parents[1]
SURE_COMMIT = "5ce0193bc93e73b1c7f1f53aeda8854e997011e2"


def test_sure_author_components_are_loaded_from_pinned_isolated_checkout():
    components = load_sure_author_components(
        REPO_ROOT / "reference/_local/SURE", pinned_commit=SURE_COMMIT
    )
    assert components.commit == SURE_COMMIT
    assert set(components.source_hashes) == {
        "train.py",
        "utils/sam.py",
        "model/classifier.py",
        "run/CIFAR10/wideresnet.sh",
    }
    assert all(len(value) == 64 for value in components.source_hashes.values())


def test_sure_indexed_loader_and_author_cosine_head():
    loader = DataLoader(
        TensorDataset(torch.randn(5, 1, 32, 32), torch.arange(5) % 2),
        batch_size=2,
        shuffle=False,
    )
    indexed = indexed_training_loader(loader)
    _images, _targets, indices = next(iter(indexed))
    assert indices.tolist() == [0, 1]

    components = load_sure_author_components(
        REPO_ROOT / "reference/_local/SURE", pinned_commit=SURE_COMMIT
    )
    model = SimpleCNN(input_channels=1, num_classes=2)
    metadata = apply_author_cosine_classifier(
        model,
        components=components,
        num_classes=2,
        temperature=8.0,
    )
    assert model(torch.randn(3, 1, 32, 32)).shape == (3, 2)
    assert metadata["head"] == "author_cosine_classifier"


def test_sure_recipe_frozen_defaults_match_author_ours_block():
    recipe = SureAuthorRecipeConfig()
    recipe.validate()
    payload = recipe.to_dict()
    assert payload["mixup_weight"] == 0.5
    assert payload["crl_weight"] == 0.5
    assert payload["mixup_beta"] == 10.0
    assert payload["author_recipe"].startswith("FMFP")
